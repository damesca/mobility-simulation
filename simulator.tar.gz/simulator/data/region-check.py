import pandas as pd

data = pd.read_csv('Area40F2.csv')
output = open('real-users.txt', 'w+')
output.write('test\n')

rngX = 0
rngY = 0
step = 40


actual = 1
accumulate = 0
for index, row in data.iterrows():
	x = row['PositionX']
	y = row['PositionY']

	if (row['Time'] == actual):
		if (((x >= rngX)and(x < (rngX+step))) and ((y >= rngY)and(y < (rngY+step)))):
			#print('Time: {}, Node: {}'.format(row['Time'], row['Node']))
			accumulate += 1
	else:
		print('Time: {}, ({},{}): {}'.format(actual, rngX, rngY, accumulate))
		string = str(accumulate) + '\n'
		output.write(string)
		actual += 1
		accumulate = 0
		if (((x >= rngX)and(x < (rngX+step))) and ((y >= rngY)and(y < (rngY+step)))):
			#print('Time: {}, Node: {}'.format(row['Time'], row['Node']))
			accumulate += 1

output.close()
