import matplotlib.pyplot as plt
import pandas as pd
import sys

data = pd.read_csv('PaperObstacle.csv')
'''
if len(sys.argv) < 2: 
	raise Error('No argument')
else:
	step = int(sys.argv[1])
'''
for x in range(1, 101):
	subframe = data[data['Time'] == x]
	num_users = subframe['Node'].max() + 1

	for u in range(0, num_users):
		x = subframe[subframe['Node'] == u]['PositionX'].values[0]
		y = subframe[subframe['Node'] == u]['PositionY'].values[0]
		#print('{}({},{})'.format(u,x,y))
		plt.plot(x,y,'o')

	plt.axvline(x=40)
	plt.axvline(x=60)
	plt.axhline(y=40)
	plt.axhline(y=60)
	plt.savefig('figs/figure{}.png'.format(x))
	plt.close()
