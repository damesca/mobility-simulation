from BloomFilter import BloomFilter
from TimeDataFrame import TimeDataFrame
from DataParser import DataParser
from DataSender import DataSender
import json
import constants

def main():

	dp = DataParser(constants.input_trace, "../data/output1.csv")

	# Compute proximity coincidences in space and time for users within a given range
	#dp.compute_proximity_with_all(2)
	dp.compute_proximity(constants.ble_range, "../data/real-contacts.txt")

	# Generate a bloom filter trace for each coincidence with a given sample interval
	dp.generate_bf_trace("../data/bfoutput1.txt")
	#dp.generate_bf_trace_with_interval("../data/bfoutput1.txt", 5)

	ds = DataSender('../data/bfoutput1.txt')

	# Execute all the simulation steps and sends data to the server
	ds.execute(
		'http://localhost:{}/report/add'.format(str(constants.proxy_port)),
		constants.simulation_steps,
		constants.time_int
	)

if __name__ == "__main__":
	main()
