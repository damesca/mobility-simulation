def map_data(data, begin=0, end=60, step=20):
    output = None
    num_steps = int((end - begin) / step)
    if (data < begin): output = begin
    elif (data > end): output = end
    else:
        for i in range(0, num_steps):
            if ((data >= (begin + i * step)) and (data < ((i+1) * step))):
                output = begin + i * step
    return output

input_trace = '../data/Area40F2.csv'
proxy_port = 6000
simulation_steps = 190
time_int = 1
ble_range = 1
x = 0
y = 0
area_step = 40
get_x = map_data(x, 0, 500, area_step)
get_y = map_data(y, 0, 500, area_step)
get_query = 'http://localhost:{}/query/?latitude={}&longitude={}'.format(
    str(proxy_port),
    str(get_x),
    str(get_y)
)
