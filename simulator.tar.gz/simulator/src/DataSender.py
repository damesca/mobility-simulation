import requests, json
import time, threading
from multiprocessing import Pool
import constants

class DataSender():

	def __init__(self, filename, data=None):
		self.__filename = filename
		self.__data = data
		self.__actual_it = 1
		self.__output_data = ""

	# url: http direction where to send reports
	# max_it: maximum number of iterations in simulation
	# interval: duration in seconds for each discrete time step
	def execute(self, url, max_it, interval):
		self.__actual_it = 1

		print("# Start execution #")
		f = open(self.__filename, 'r')
		self.__data = [json.loads(line) for line in f]
		f.close()

		self.__timed_get(url, max_it, interval)

		return 0

	def __timed_get(self, url, max_it, interval):
		print("# Execute interval " + str(self.__actual_it))
		body = []
		if self.__data[0]['iter'] == self.__actual_it:
			while self.__data[0]['iter'] == self.__actual_it:
				body.append(self.__data.pop(0)['bloom_filter'])
			#print(body)

		# TODO: send data with ThreadPoolExecutor
		res = self.__put_many(url, body)
		#print(res)

		get_result = requests.get(constants.get_query)
		print('Get({},{}): {}'.format(str(constants.get_x), str(constants.get_y), get_result.text))
		estimation = json.loads(get_result.text)['cardinality']
		self.__output_data += (str(estimation) + '\n')

		#get_result = requests.get('http://localhost:6000/query/?latitude=20&longitude=40')
		#print('Get(20,40): {}'.format(get_result.text))

		self.__actual_it += 1
		if self.__actual_it < max_it:
			threading.Timer(interval, self.__timed_get, [url, max_it, interval]).start()
		else:
			self.__data = []
			self.__actual_it = 1
			output = open('../data/estimated-users.txt', 'w+')
			output.write(self.__output_data)
			output.close()

		return 0

	def __get(self, url, data=""):
		r = requests.get(url)
		print("[GET]: {data}...".format(data=str(d)[:12]))
		return r

	def __get_many(self, url, data=""):
		response = []
		for d in data:
			response.append(requests.get(url).status_code)
			print("[GET]: {data}...".format(data=str(d)[:12]))
		return response

	def __put_many(self, url, data=""):
		response = []
		headers = {'Content-Type': 'application/json'}
		for d in data:
			d_json = json.dumps(d)
			#print(d_json)
			r = requests.put(url, headers=headers, data=d_json)
			#print(r)
			response.append(r.status_code)
			#print("[PUT]: {data}...".format(data=str(d)[:12]))
		return response

	# TODO: restructure
	def __post(self, url, data):
		r = requests.post(url, data = data)
		return r

	# TODO: restructure
	def __post_many(self, url):
		response = []

		f = open(self.__filename, 'r')
		for line in f:
			json_data = json.loads(line)
			response.append(self.post(url, json_data).status_code)
		f.close()

		return response
