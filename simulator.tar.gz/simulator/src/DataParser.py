from TimeDataFrame import TimeDataFrame
from BloomFilter import BloomFilter
import pandas as pd
import json
import constants

class DataParser():

	def __init__(self, input_file, output_file):
		self.__df = TimeDataFrame(input_file)
		self.__max_it = self.__df.get_max_it()
		self.__max_users = self.__df.get_max_user()
		self.__of = output_file

	def output_print_data(self, data="test"):
		try:
			f = open(self.__of, 'w+')
			if(isinstance(data, list)):
				for item in data:
					f.write(item)
			else:
				f.write(str(data))
		except:
			raise Exception("Failed to write data to output file")
		finally:
			f.close()

	def inRange(self, x0, y0, x1, y1, length):
		return ((abs(x0 - x1) <= length) and (abs(y0 - y1) <= length))


	def compute_proximity(self, length, output_file):
		output = ["Iter,RefId,RefPX,RefPY,CmpId,CmpPX,CmpPY\n"]
		contacts_file = open(output_file, 'w+')
		contacts_file.write('test\n')

		for it in range(1, self.__max_it + 1):

			real_contacts = []
			df = self.__df.get_it_dataframe(it)
			posX = df['PositionX'].tolist()
			posY = df['PositionY'].tolist()

			for ref_id in range(0, len(posX)):
				for comp_id in range(0, len(posY)):
					if(ref_id != comp_id):
						if(self.inRange(posX[ref_id], posY[ref_id], posX[comp_id], posY[comp_id], length)):
							output.append(
								str(it) +','+ str(ref_id) +','+ str(posX[ref_id]) +','+ str(posY[ref_id]) +','+
								str(comp_id) +','+ str(posX[comp_id]) +','+ str(posY[comp_id]) + '\n'
							)
							if((posX[ref_id] >= constants.get_x) and (posX[ref_id] < (constants.get_x + constants.area_step)) and
								(posY[ref_id] >= constants.get_y) and (posY[ref_id] < (constants.get_y + constants.area_step))):
								print('Ref: {}, Cmp: {}, InRange'.format(ref_id, comp_id))
								if ref_id not in real_contacts:
									real_contacts.append(ref_id)
			print('It: {}, RC: {}'.format(it, real_contacts))
			contacts_file.write(str(len(real_contacts)) + '\n')
		contacts_file.close()
		self.output_print_data(output)

	def compute_proximity_with_all(self, length):
		output = ["Iter,RefId,RefPX,RefPY,CmpId,CmpPX,CmpPY\n"]

		for it in range(1, self.__max_it + 1):

			df = self.__df.get_it_dataframe(it)
			posX = df['PositionX'].tolist()
			posY = df['PositionY'].tolist()

			for ref_id in range(0, len(posX)):
				output.append('{},{},{},{},{},{},{}\n'.format(
					it, ref_id, posX[ref_id], posY[ref_id],
					ref_id, posX[ref_id], posY[ref_id]
				))
				for comp_id in range(0, len(posY)):
					if((ref_id != comp_id)):
						if(self.inRange(posX[ref_id], posY[ref_id], posX[comp_id], posY[comp_id], length)):
							output.append(
								str(it) +','+ str(ref_id) +','+ str(posX[ref_id]) +','+ str(posY[ref_id]) +','+
								str(comp_id) +','+ str(posX[comp_id]) +','+ str(posY[comp_id]) + '\n'
							)
		self.output_print_data(output)

	# TODO: refactor pandas behaviour
	def generate_bf_trace(self, filename):
		try:
			output_f = open(filename, 'w+')
			data = pd.read_csv(self.__of)
			print('GEN-BF: read-csv-ok')

			for index, row in data.iterrows():
				bf = BloomFilter()
				bf.insert(row['RefId'])
				bf.insert(row['CmpId'])
				json_data = dict()
				json_data['iter'] = int(row['Iter'])
				json_data['bloom_filter'] = bf.toJson()
				json_data['bloom_filter']['location'] = {
					'latitude': int(row['RefPX']),
					'longitude': int(row['RefPY'])
				}
				### TMP ####
				#if((row['RefPX'] >= 40)and(row['RefPX'] < 60)and(row['RefPY'] >= 0)and(row['RefPY'] < 20)):
				############
				output_f.write(str(json.dumps(json_data)) + '\n')
				print('GEN-BF: write-data-({},{})'.format(row['RefPX'],row['RefPY']))

		except:
			raise Exception("Failed to write data to file")
		finally:
			output_f.close()

	# step: number of discrete time intervals for the sampling rate
	def generate_bf_trace_with_interval(self, filename, step):

		data = pd.read_csv(self.__of)

		data_to_file = []
		for i in range(0, self.__max_it, step):

			user_array = [ {
				'node': e, 'bf': BloomFilter(), 'rows': []
			} for e in range(0, self.__max_users + 1) ]

			print("i: " + str(i) + ", i+s: " + str(i+step))
			subdata = data[(data['Iter'] >= i) & (data['Iter'] < (i+step))]

			for index, row in subdata.iterrows():
				user_array[int(row['RefId'])]['rows'].append(
					{ 'CmpId': int(row['CmpId']),
						'RefPX': int(row['RefPX']),
						'RefPY': int(row['RefPY']) }
				)

			for user in user_array:
				if user['rows'] != []:
					user['bf'].insert('node')
					for e in user['rows']:
						user['bf'].insert(e['CmpId'])
					init_posX = user['rows'][0]['RefPX']
					init_posY = user['rows'][0]['RefPY']
					end_posX = user['rows'][len(user['rows'])-1]['RefPX']
					end_posY = user['rows'][len(user['rows'])-1]['RefPY']
					meanX = (end_posX + init_posX) / 2
					meanY = (end_posY + init_posY) / 2

					json_data = dict()
					json_data['iter'] = i + step
					json_data['bloom_filter'] = user['bf'].toJson()
					json_data['bloom_filter']['location'] = {
						'latitude': meanX,
						'longitude': meanY
					}
					data_to_file.append(json_data)

		output_f = open(filename, 'w+')
		for data in data_to_file:
			output_f.write(str(json.dumps(data)) + '\n')
		output_f.close()
