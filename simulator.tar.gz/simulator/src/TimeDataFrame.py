import pandas as pd

class TimeDataFrame():

	def __init__(self, filename):
		try:
			self.__data = pd.read_csv(filename)
			self.__max_it = self.__data['Time'].max()
			self.__max_user = self.__data['Node'].max()
		except:
			raise Exception("Specified file is not a correct csv file")
			
	def get_max_it(self):
		return self.__max_it
		
	def get_max_user(self):
		return self.__max_user
	
	def get_dataframe(self):
		return self.__data
		
	def get_it_dataframe(self, it):
		if (it < 1 or it > self.__max_it):
			return None
		else:
			return self.__data.loc[self.__data['Time'] == it]
