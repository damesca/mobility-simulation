import hashlib
import json
import math

class BloomFilter():

	def __init__(self, m=500, k=3, data=''):
		self.__m = m
		self.__k = k
		self.__card = 0
		if data == '':
			self.__array = '0' * m
		else:
			self.__m = len(data)
			self.__array = data
			for x in data:
				if x == '1': self.__card += 1

	def __str__(self):
		return self.__array

	#TODO: fix integer to byte encoding (no str mediation)
	def insert(self, e):
		for i in range(0, self.__k):
			hfunc = hashlib.sha256()
			hfunc.update(bytes(str(e), encoding='utf-8'))
			hfunc.update(bytes(str(i), encoding='utf-8'))
			res = int(hfunc.hexdigest(), 16)
			pos = res % self.__m
			data = list(self.__array)
			data[pos] = '1'
			self.__array = "".join(data)
		self.__card += 1
			#print("Res: " + str(res) + ", Pos: " + str(pos))

	def check(self, e):
		ok = True
		for i in range(0, self.__k):
			hfunc = hashlib.sha256()
			hfunc.update(bytes(str(e), encoding='utf-8'))
			hfunc.update(bytes(str(i), encoding='utf-8'))
			res = int(hfunc.hexdigest(), 16)
			pos = res % self.__m
			if (self.__array[pos] != '1'): ok = False
		return ok

	def estimate_cardinality(self):
		z = 0
		for e in self.__array:
			if e == '0':
				z += 1
		if z == 0: z = 1
		return math.log(z/self.__m) / (self.__k * math.log(1 - (1/self.__m)))

	def get_card(self):
		return self.__card

	def get_length(self):
		return self.__m

	def get_array(self):
		return self.__array

	def toJson(self) -> dict:
		return {
			'filter': self.__array
		}

	def add(self, bf):
		if self.get_length() == bf.get_length():
			bf_array = bf.get_array()
			for i in range(0, self.__m):
				own_array = True if self.__array[i] == '1' else False
				other_array = True if bf_array[i] == '1' else False
				res = own_array or other_array
				data = list(self.__array)
				data[i] = '1' if res else '0'
				self.__array = "".join(data)
