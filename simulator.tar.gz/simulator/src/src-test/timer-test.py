import time, threading

data = [
	'i1', 'i2', 'i3', 'i4', 'i5', 'i6', 'i7'
]
it = 0

def foo(it):
	print(data[it])
	print(time.ctime())
	it += 1
	if it < 7:
		threading.Timer(2, foo, args=(it,)).start()
	
foo(it)
