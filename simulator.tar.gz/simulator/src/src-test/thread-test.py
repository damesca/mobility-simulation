import threading
import time 
from queue import Queue

print_lock = threading.Lock()

class MyThread(threading.Thread):
	def __init__(self, queue, args=(), kwargs=None):
		threading.Thread.__init__(self, args=(), kwargs=None)
		self.queue = queue
		self.daemon = True
		self.receive_messages = args[0]
		
	def do_thing_with_message(self, message):
		if self.receive_messages:
			with print_lock:
				print(f'{threading.currentThread().getName()}, Received {message}')	
				
	def read_queue(self):
		val = self.queue.get()
		while val is not None:
			self.do_thing_with_message(val)
			val = self.queue.get()
		threading.Timer(10, self.read_queue, args=()).start()
	
	def run(self):
		print(f'{threading.currentThread().getName()}, {self.receive_messages}')
		self.read_queue()
		
if __name__ == '__main__':
	threads = []
	for t in range(10):
		q = Queue()
		threads.append(MyThread(q, args=(t % 2 == 0,)))
		threads[t].start()
		time.sleep(0.1)
	
	num = 0
	
	def send_message():
		global num
		message = "Print this! " + str(num)
		for t in threads:
			t.queue.put(message)
		num += 1
		threading.Timer(2, send_message, args=()).start()
		
	send_message()
	
	for t in threads:
		t.join()
