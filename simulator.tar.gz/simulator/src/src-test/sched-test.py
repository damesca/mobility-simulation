import sched, time
s = sched.scheduler(time.time, time.sleep)
def print_time(a='default'):
	print("From print_time", time.time(), a)
	
def send_message(m=0):
	print("From send_message:", time.time(), str(m))
	
def print_some_times():
	m = 1
	print(time.time())
	s.enter(5, 1, send_message, kwargs={'m': m})
	m += 1
	s.enter(10, 1, send_message, kwargs={'m': m})
	s.run()
	print(time.time())
	
	
print_some_times()
