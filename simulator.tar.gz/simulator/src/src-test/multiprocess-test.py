from multiprocessing import Process
import time
from queue import Queue
import multiprocessing

def read_queue(idx, q):
	val = q.get()
	if val is not None:
		print(str(idx) + ' ' + str(val))
	#threading.Timer(10, self.read_queue, args=()).start()

def f(idx, q):
	print(idx)
	#read_queue(idx, q)
	
	
if __name__ == '__main__':
	p = []
	q = []
	
	print("Number of cpu: ", multiprocessing.cpu_count())
	
	for i in range(0, 2):
		qu = Queue()
		q.append(qu)
		p.append(Process(target=f, args=(i, qu,)))
		
	for proc in p:
		proc.start()
		
		
	for proc in p:
		proc.join()
